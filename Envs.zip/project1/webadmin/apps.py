from django.apps import AppConfig


class WebadminConfig(AppConfig):
    name = 'webadmin'
